/*==================== SHOW MENU ====================*/
const navMenu = document.getElementById('nav-menu'),
      navToggle = document.getElementById('nav-toggle'),
      navClose = document.getElementById('nav-close')

/*===== MENU SHOW =====*/
/* Validate if constant exists */
if(navToggle){
    navToggle.addEventListener('click', () =>{
        navMenu.classList.add('show-menu')
    })
}

/*===== MENU HIDDEN =====*/
/* Validate if constant exists */
if(navClose){
    navClose.addEventListener('click', () =>{
        navMenu.classList.remove('show-menu')
    })
}

/*==================== REMOVE MENU MOBILE ====================*/
const navLink = document.querySelectorAll('.nav__link')

function linkAction(){
    const navMenu = document.getElementById('nav-menu')
    // When we click on each nav__link, we remove the show-menu class
    navMenu.classList.remove('show-menu')
}
navLink.forEach(n => n.addEventListener('click', linkAction))

/*==================== SCROLL SECTIONS ACTIVE LINK ====================*/
const sections = document.querySelectorAll('section[id]')

function scrollActive(){
    const scrollY = window.pageYOffset

    sections.forEach(current =>{
        const sectionHeight = current.offsetHeight
        const sectionTop = current.offsetTop - 50;
        const sectionId = current.getAttribute('id')

        if(scrollY > sectionTop && scrollY <= sectionTop + sectionHeight){
            document.querySelector('.nav__menu a[href*=' + sectionId + ']').classList.add('active-link')
        }else{
            document.querySelector('.nav__menu a[href*=' + sectionId + ']').classList.remove('active-link')
        }
    })
}
window.addEventListener('scroll', scrollActive)

/*==================== CHANGE BACKGROUND HEADER ====================*/ 
function scrollHeader(){
    const nav = document.getElementById('header')
    // When the scroll is greater than 200 viewport height, add the scroll-header class to the header tag
    if(this.scrollY >= 80) nav.classList.add('scroll-header'); else nav.classList.remove('scroll-header')
}
window.addEventListener('scroll', scrollHeader)

/*==================== SHOW SCROLL UP ====================*/ 
function scrollUp(){
    const scrollUp = document.getElementById('scroll-up');
    // When the scroll is higher than 560 viewport height, add the show-scroll class to the a tag with the scroll-top class
    if(this.scrollY >= 560) scrollUp.classList.add('show-scroll'); else scrollUp.classList.remove('show-scroll')
}
window.addEventListener('scroll', scrollUp)

/*==================== DARK LIGHT THEME ====================*/ 
const themeButton = document.getElementById('theme-toggle')
const darkTheme = 'dark-theme'
const iconTheme = 'bx-sun'

// Previously selected topic (if user selected)
const selectedTheme = localStorage.getItem('selected-theme')
const selectedIcon = localStorage.getItem('selected-icon')

// We obtain the current theme that the interface has by validating the dark-theme class
const getCurrentTheme = () => document.body.getAttribute('data-theme') === 'dark' ? 'dark' : 'light'
const getCurrentIcon = () => themeButton.querySelector('i').classList.contains(iconTheme) ? 'bx-moon' : 'bx-sun'

// We validate if the user previously chose a topic
if (selectedTheme) {
  // If the validation is fulfilled, we ask what the issue was to know if we activated or deactivated the dark
  document.body.setAttribute('data-theme', selectedTheme)
  themeButton.querySelector('i').classList[selectedTheme === 'dark' ? 'add' : 'remove'](iconTheme)
}

// Activate / deactivate the theme manually with the button
themeButton.addEventListener('click', () => {
    // Add or remove the dark / icon theme
    const currentTheme = getCurrentTheme()
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark'
    
    document.body.setAttribute('data-theme', newTheme)
    themeButton.querySelector('i').classList.toggle(iconTheme)
    
    // We save the theme and the current icon that the user chose
    localStorage.setItem('selected-theme', newTheme)
    localStorage.setItem('selected-icon', getCurrentIcon())
})

/*==================== LANGUAGE TOGGLE ====================*/
const languageButton = document.getElementById('language-toggle')
const languageText = document.querySelector('.language-text')

// Get current language from localStorage or default to Arabic
let currentLanguage = localStorage.getItem('selected-language') || 'ar'

// Function to update content based on language
function updateLanguage(lang) {
    const elements = document.querySelectorAll('[data-ar][data-en]')
    const placeholderElements = document.querySelectorAll('[data-placeholder-ar][data-placeholder-en]')
    
    elements.forEach(element => {
        if (lang === 'ar') {
            element.textContent = element.getAttribute('data-ar')
        } else {
            element.textContent = element.getAttribute('data-en')
        }
    })
    
    // Update placeholders
    placeholderElements.forEach(element => {
        if (lang === 'ar') {
            element.placeholder = element.getAttribute('data-placeholder-ar')
        } else {
            element.placeholder = element.getAttribute('data-placeholder-en')
        }
    })
    
    // Update HTML attributes
    const html = document.documentElement
    if (lang === 'ar') {
        html.setAttribute('lang', 'ar')
        html.setAttribute('dir', 'rtl')
        languageText.textContent = 'EN'
    } else {
        html.setAttribute('lang', 'en')
        html.setAttribute('dir', 'ltr')
        languageText.textContent = 'عر'
    }
    
    // Update page title
    if (lang === 'ar') {
        document.title = 'عبدالله أبوكرش - موقع شخصي'
    } else {
        document.title = 'Abdullah Abukrash - Personal Website'
    }
}

// Initialize language on page load
updateLanguage(currentLanguage)

// Language toggle event listener
languageButton.addEventListener('click', () => {
    currentLanguage = currentLanguage === 'ar' ? 'en' : 'ar'
    updateLanguage(currentLanguage)
    localStorage.setItem('selected-language', currentLanguage)
})

/*==================== SMOOTH SCROLLING ====================*/
const scrollLinks = document.querySelectorAll('a[href^="#"]')

scrollLinks.forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault()
        
        const targetId = link.getAttribute('href').substring(1)
        const targetSection = document.getElementById(targetId)
        
        if (targetSection) {
            const headerHeight = document.querySelector('.header').offsetHeight
            const targetPosition = targetSection.offsetTop - headerHeight
            
            window.scrollTo({
                top: targetPosition,
                behavior: 'smooth'
            })
        }
    })
})

/*==================== CONTACT FORM ====================*/
const contactForm = document.querySelector('.contact__form')

if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
        e.preventDefault()
        
        // Get form data
        const formData = new FormData(contactForm)
        const name = contactForm.querySelector('input[type="text"]').value
        const email = contactForm.querySelector('input[type="email"]').value
        const message = contactForm.querySelector('textarea').value
        
        // Simple validation
        if (!name || !email || !message) {
            alert(currentLanguage === 'ar' ? 'يرجى ملء جميع الحقول' : 'Please fill all fields')
            return
        }
        
        // Email validation
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
        if (!emailRegex.test(email)) {
            alert(currentLanguage === 'ar' ? 'يرجى إدخال بريد إلكتروني صحيح' : 'Please enter a valid email address')
            return
        }
        
        // Success message
        alert(currentLanguage === 'ar' ? 'تم إرسال الرسالة بنجاح!' : 'Message sent successfully!')
        
        // Reset form
        contactForm.reset()
    })
}

/*==================== TYPING ANIMATION ====================*/
function typeWriter(element, text, speed = 100) {
    let i = 0
    element.innerHTML = ''
    
    function type() {
        if (i < text.length) {
            element.innerHTML += text.charAt(i)
            i++
            setTimeout(type, speed)
        }
    }
    
    type()
}

/*==================== SCROLL REVEAL ANIMATION ====================*/
function revealOnScroll() {
    const reveals = document.querySelectorAll('[data-aos]')
    
    reveals.forEach(element => {
        const windowHeight = window.innerHeight
        const elementTop = element.getBoundingClientRect().top
        const elementVisible = 150
        
        if (elementTop < windowHeight - elementVisible) {
            element.classList.add('aos-animate')
        }
    })
}

window.addEventListener('scroll', revealOnScroll)

/*==================== PRELOADER ====================*/
window.addEventListener('load', () => {
    const preloader = document.querySelector('.preloader')
    if (preloader) {
        preloader.style.opacity = '0'
        setTimeout(() => {
            preloader.style.display = 'none'
        }, 500)
    }
})

/*==================== INITIALIZE AOS ====================*/
document.addEventListener('DOMContentLoaded', function() {
    // Initialize AOS (Animate On Scroll)
    if (typeof AOS !== 'undefined') {
        AOS.init({
            duration: 1000,
            easing: 'ease-in-out',
            once: true,
            mirror: false
        })
    }
    
    // Initialize scroll reveal for elements without AOS
    revealOnScroll()
})

/*==================== WORK FILTER ====================*/
const workFilters = document.querySelectorAll('.work__filter')
const workItems = document.querySelectorAll('.work__item')

if (workFilters.length > 0) {
    workFilters.forEach(filter => {
        filter.addEventListener('click', () => {
            // Remove active class from all filters
            workFilters.forEach(f => f.classList.remove('active'))
            // Add active class to clicked filter
            filter.classList.add('active')
            
            const filterValue = filter.getAttribute('data-filter')
            
            workItems.forEach(item => {
                if (filterValue === 'all' || item.classList.contains(filterValue)) {
                    item.style.display = 'block'
                    setTimeout(() => {
                        item.style.opacity = '1'
                        item.style.transform = 'scale(1)'
                    }, 100)
                } else {
                    item.style.opacity = '0'
                    item.style.transform = 'scale(0.8)'
                    setTimeout(() => {
                        item.style.display = 'none'
                    }, 300)
                }
            })
        })
    })
}

/*==================== PARALLAX EFFECT ====================*/
window.addEventListener('scroll', () => {
    const scrolled = window.pageYOffset
    const parallaxElements = document.querySelectorAll('.parallax')
    
    parallaxElements.forEach(element => {
        const speed = element.dataset.speed || 0.5
        const yPos = -(scrolled * speed)
        element.style.transform = `translateY(${yPos}px)`
    })
})

/*==================== COUNTER ANIMATION ====================*/
function animateCounters() {
    const counters = document.querySelectorAll('.counter')
    
    counters.forEach(counter => {
        const target = parseInt(counter.getAttribute('data-target'))
        const increment = target / 200
        let current = 0
        
        const updateCounter = () => {
            if (current < target) {
                current += increment
                counter.textContent = Math.ceil(current)
                setTimeout(updateCounter, 10)
            } else {
                counter.textContent = target
            }
        }
        
        updateCounter()
    })
}

/*==================== INTERSECTION OBSERVER FOR ANIMATIONS ====================*/
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
}

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('animate')
            
            // Trigger counter animation if element has counter class
            if (entry.target.classList.contains('counter-section')) {
                animateCounters()
            }
        }
    })
}, observerOptions)

// Observe all sections
document.querySelectorAll('section').forEach(section => {
    observer.observe(section)
})

/*==================== BACK TO TOP SMOOTH SCROLL ====================*/
const scrollUpButton = document.getElementById('scroll-up')

if (scrollUpButton) {
    scrollUpButton.addEventListener('click', (e) => {
        e.preventDefault()
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        })
    })
}

/*==================== NAVBAR BACKGROUND ON SCROLL ====================*/
window.addEventListener('scroll', () => {
    const header = document.querySelector('.header')
    if (window.scrollY > 100) {
        header.style.backgroundColor = currentLanguage === 'dark' ? 
            'rgba(12, 12, 12, 0.95)' : 'rgba(255, 255, 255, 0.95)'
        header.style.backdropFilter = 'blur(10px)'
    } else {
        header.style.backgroundColor = 'transparent'
        header.style.backdropFilter = 'none'
    }
})

/*==================== LOADING ANIMATION ====================*/
function showLoadingAnimation() {
    const loadingElements = document.querySelectorAll('.loading')
    
    loadingElements.forEach((element, index) => {
        setTimeout(() => {
            element.classList.add('loaded')
        }, index * 200)
    })
}

// Call loading animation on page load
window.addEventListener('load', showLoadingAnimation)

/*==================== MOBILE MENU CLOSE ON OUTSIDE CLICK ====================*/
document.addEventListener('click', (e) => {
    const navMenu = document.getElementById('nav-menu')
    const navToggle = document.getElementById('nav-toggle')
    
    if (!navMenu.contains(e.target) && !navToggle.contains(e.target)) {
        navMenu.classList.remove('show-menu')
    }
})

/*==================== KEYBOARD NAVIGATION ====================*/
document.addEventListener('keydown', (e) => {
    // Close mobile menu with Escape key
    if (e.key === 'Escape') {
        const navMenu = document.getElementById('nav-menu')
        navMenu.classList.remove('show-menu')
    }
    
    // Navigate sections with arrow keys
    if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
        e.preventDefault()
        const sections = Array.from(document.querySelectorAll('section[id]'))
        const currentSection = sections.find(section => {
            const rect = section.getBoundingClientRect()
            return rect.top <= 100 && rect.bottom >= 100
        })
        
        if (currentSection) {
            const currentIndex = sections.indexOf(currentSection)
            let nextIndex
            
            if (e.key === 'ArrowUp') {
                nextIndex = currentIndex > 0 ? currentIndex - 1 : sections.length - 1
            } else {
                nextIndex = currentIndex < sections.length - 1 ? currentIndex + 1 : 0
            }
            
            const nextSection = sections[nextIndex]
            const headerHeight = document.querySelector('.header').offsetHeight
            
            window.scrollTo({
                top: nextSection.offsetTop - headerHeight,
                behavior: 'smooth'
            })
        }
    }
})

/*==================== PERFORMANCE OPTIMIZATION ====================*/
// Debounce function for scroll events
function debounce(func, wait) {
    let timeout
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout)
            func(...args)
        }
        clearTimeout(timeout)
        timeout = setTimeout(later, wait)
    }
}

// Apply debounce to scroll events
const debouncedScrollActive = debounce(scrollActive, 10)
const debouncedScrollHeader = debounce(scrollHeader, 10)
const debouncedScrollUp = debounce(scrollUp, 10)

// Replace original scroll listeners with debounced versions
window.removeEventListener('scroll', scrollActive)
window.removeEventListener('scroll', scrollHeader)
window.removeEventListener('scroll', scrollUp)

window.addEventListener('scroll', debouncedScrollActive)
window.addEventListener('scroll', debouncedScrollHeader)
window.addEventListener('scroll', debouncedScrollUp)

