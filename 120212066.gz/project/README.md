# عبدالله أبوكرش - موقع شخصي | Abdullah Abukrash - Personal Website

موقع شخصي احترافي مطور باستخدام HTML و CSS و JavaScript مع دعم اللغتين العربية والإنجليزية والوضع الفاتح والداكن.

A professional personal website developed using HTML, CSS, and JavaScript with support for Arabic and English languages and light/dark mode.

## المميزات | Features

- ✅ تصميم متجاوب (Responsive Design) لجميع أحجام الشاشات
- ✅ دعم اللغتين العربية والإنجليزية مع تبديل سلس
- ✅ الوضع الفاتح والداكن مع حفظ الإعدادات في Local Storage
- ✅ تأثيرات حركية باستخدام مكتبة AOS
- ✅ تصميم حديث وأنيق
- ✅ أقسام متعددة: الرئيسية، نبذة، أعمالي، المدونة، تواصل
- ✅ زر الصعود إلى الأعلى
- ✅ قائمة تنقل متجاوبة للهواتف المحمولة
- ✅ تفعيل الروابط عند التمرير للأقسام

## التقنيات المستخدمة | Technologies Used

- HTML5
- CSS3 (مع CSS Variables للألوان والخطوط)
- JavaScript (ES6+)
- Google Fonts (Jost)
- BoxIcons
- AOS (Animate On Scroll) Library

## الألوان | Colors

- اللون الأساسي: `#c07f50`
- الوضع الفاتح:
  - خلفية: `#ffffff`
  - خلفية ثانوية: `#f8f2ed`
  - نص: `#1a1e21`
- الوضع الداكن:
  - خلفية: `#0c0c0c`
  - خلفية ثانوية: `#111111`
  - نص: `#ffffff`

## الخطوط | Fonts

- الخط الأساسي: Jost (Google Fonts)
- خط الشعار: Tuesday Night (مخصص)

## هيكل المشروع | Project Structure

```
project/
├── index.html
├── css/
│   └── style.css
├── js/
│   └── script.js
├── images/
│   ├── personal/
│   ├── work/
│   └── blog/
└── README.md
```

## كيفية التشغيل | How to Run

1. قم بتحميل المشروع
2. افتح ملف `index.html` في المتصفح
3. أو استخدم خادم محلي مثل Live Server

## المطور | Developer

**عبدالله أبوكرش**
- التخصص: وسائط متعددة (مالتيميديا)
- الجامعة: الجامعة الإسلامية بغزة
- الهاتف: 0599239415
- فيسبوك: [رابط الفيسبوك](https://www.facebook.com/share/1Hrw6R1LjY/)

## الترخيص | License

هذا المشروع مطور لأغراض تعليمية وشخصية.

This project is developed for educational and personal purposes.

---

© 2024 عبدالله أبوكرش. جميع الحقوق محفوظة | Abdullah Abukrash. All rights reserved.

